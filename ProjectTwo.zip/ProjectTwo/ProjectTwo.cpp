//DANIEL PHAM
//PROJECT TWO 
//02/20/2022
//For project two, we are to follow up on Project one by using the data structures that we compared between vector, hash table and tree. Since in project one, the data structure that I thought would
//best for this project two was vectors, I created pseudocode for it and now we are using the pseudocode we made last week to complete Project two. just like in project one, we are to design a program that could
//read the course data file (courseInfo.txt) and store it. display a menu for the users to select which option they wanted. The options are; load data structure, print course list, and print a specific course.


#include <iostream>
#include <fstream>
#include <vector>
#include <string>//crucial for ONE command in this entire project; "getline"

using namespace std;
//making all the variables in this group public by using "struct" and defining the structure and its variables.
struct Course {
	string courseNum;
	string courseName;
	vector<string> preReqs;

};

vector<string> tokenize(string s, string del = " ") {//tokenize splits strings with respect to delimiter(s)
	vector<string> stringArray;

	int start = 0;
	int stop = s.find(del);
	while (stop != -1)
	{
		stringArray.push_back(s.substr(start, stop - start)); //adding elements into the vector from the back using the push_back function
		start = stop + del.size();
		stop = s.find(del, start);
	}
	stringArray.push_back(s.substr(start, stop - start));//adding elements into the vector from the back using the push_back function
	return stringArray;
}

//loading and storing the details of "courseInfo" into "classes"
vector<Course> LoadDataStructure() {
	//using ifstream to open and read input from a file.
	ifstream list("courseInfo.txt", ios::in); //"ios in" reads operations from a courseInfo
	vector<Course> cs;
	string line;
	//creating a loop that reads every line in the uploaded file "courseInfo"
	while (1)
	{
		getline(list, line);
		//breaking the loop once every line in the file "courseInfo" has been read
		if (line == "-1")
			break;

		Course classes;
		//the fuction tokenizedInformation is splitting a string
		vector<string> tokenizedInformation = tokenize(line, ","); //delimiter for this string is a comma
		//assigning information from the file to the structure. (struct Course)
		classes.courseNum = tokenizedInformation[0];//assigning info read from CourseInfo to variables WITHIN the struct in this case it is CourseNum
		classes.courseName = tokenizedInformation[1];//assigning info read from CourseInfo to variables WITHIN the struct in this case it is name

		//function to store the prereqs IF course requires prereqs
		for (int i = 2; i < tokenizedInformation.size(); i++) {
			classes.preReqs.push_back(tokenizedInformation[i]);//adding elements into list of courses from the back using the push_back function
		}

		cs.push_back(classes);//adding elements into list of courses from the back using the push_back function
	}
	list.close(); //assined variable of courseinfo.txt is being closed

	return cs; //returning the read operations for courseinfo.txt
}
//after the file has been loaded into the data structure, it program created above then sorts the contents of courseinfo according.
//1.A.
//prints the information for ONE SPECIFIC course that's given by the user
void printCourse(Course classes) {
	string courseNum = classes.courseNum;
	string courseName = classes.courseName;
	vector<string> preReqs = classes.preReqs;
	//printing the courses name and number do NOT have conditions as every course has a name and number
	cout << "Course Number: " << courseNum << endl;
	cout << "Course Name: " << courseName << endl;
	cout << "Prerequisites: ";//however, some courses have preReqs and some do not so this is the condition to print the preReqs if needed.
	for (int i = 0; i < preReqs.size(); i++) {
		cout << preReqs[i] << " ";
	}
	cout << "\n\n\n\n"; //line seperator
}
//prints the information for ALL 
//now it is time to load and display (print) the course list in an alphanumeric list. 2.B.
void printCourseList(vector<Course> cs) {
	int n = cs.size();
	//bubble sorting is the easiest method for displaying the list is the right alphanumeric order
	for (int i = 0; i < n - 1; i++) {
		for (int j = 0; j < n - i - 1; j++) {
			if (cs[j].courseNum > cs[j + 1].courseNum) { //condition for bubble sorting, and basically swap IF and ONLY IF
				swap(cs[j + 1], cs[j]);
			}
		}
	}
	for(int i = 0; i < n; i++) {
	printCourse(cs[i]);
	}
}
//function to print course title and prereqs based on the course number entered by the user
void searchCourse(vector<Course> cs) {
	int num = cs.size();
	string courseNum;
	int f = 0;//setting any course number not on our list to zero

	cout << "Please enter the Courses' Number";//display a command for the user to input an integer
	cin >> courseNum;//takes the users input and assigns it to courseNum
	//since the user gets to input any iteger they would like, there's a chance that they may input a typo or simply one that does not exist so parameters have to be set for that
	for (int i = 0; i < num; i++) {
		if (cs[i].courseNum == courseNum) {//condition if the user input matches and is found on our list, then print it
			f = 1;
			printCourse(cs[i]);
			break;
		}
	}

	//condition if the user input does NOT match anything on our list, we then have to let them know that it does not exist and to try again.
	if (f == 0) {
		cout << "Course number entered does not exist. Please try again. \n";
	}
}
int main(int argc, char** argv){
	vector<Course> cs;
	//displaying a menu that prompts the user for menu options, and the user makes their selections with the characters right before the options (a,b,c,d)
	cout << "1.Load Data Structure\n";
	cout << "2.Print Course List\n";
	cout << "3.Print Course\n";
	cout << "9.Exit\n";

	int sel; //assigning the menu option to a variable

	//creating a loop unless 9 is selected which in this case breaks the loop
	do {
		cout << "Please enter the number that refers to the menu option that you would like to select.";
		cin >> sel; //assigning the int entered by the user
		//the switch statement allows the program to proceed if and ONLY if the user enters a valid option
		switch (sel) {
		case 1: cs = LoadDataStructure(); break;

		case 2: cout << "Here is sample schedule:\n\n";
				cout << "CSCI100, Introduction to Computer Science\n";
				cout << "CSCI101, Introduction to Programming in C++\n";
				cout << "CSCI200, Data Structures\n";
				cout << "CSCI301, Advance Programming in C++\n";
				cout << "CSCI300, Introduction to Algorithms\n";
				cout << "CSCI350, Operating Systems\n";
				cout << "CSCI400, Large Software Development\n";
				cout << "MATH201, Discrete Mathematics\n\n"; break;

		case 3: searchCourse(cs); break;
		case 9: cout << "Exiting program. Thank you for using the course planner! \n"; break;
		default: cout << "Invalid option! Please only enter 1, 2, 3, or 9 \n";
		}


	} while (sel != 9);

	return 0;

		

	}







